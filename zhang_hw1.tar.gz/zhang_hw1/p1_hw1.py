import sys

#Prompting input
Cel = input("Give temperature in Celsius: ")

#converts input into float
Cel = float(Cel)

#calculates temperature in Fahrenheits
F = Cel*9.0/5 + 32.0
print("Temperature in Fahrenheit: " + str(F))
