import sys

x = input("Enter x: ")
x = float(x)
print(2*x*x - 3*x+2)
