import sys

x = input("Enter x: ")
y = input("Enter y: ")

x = float(x)
y = float(y)

#checks for y=0  
while not y:
    y = input("Cannot divide by 0. Enter y: ")
    y =float(y)

diff = x-y
print ("x-y=%.4f" % diff)
print ("x/y=%.4f" % (x/y))

