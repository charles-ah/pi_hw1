import numpy as np

print("for loop ...")

sum=0
for x in range(1,10001,2):
    sum+=x
print("sum="+str(sum))

print("while loop ...")

x=1
sum=0

while x<=10000:
    sum+=x
    x+=2

print("sum="+str(sum))

print("numpy array ...")

arr = np.arange(1,10001,2)
#print(arr)
print("sum="+str(np.sum(arr)))
    
